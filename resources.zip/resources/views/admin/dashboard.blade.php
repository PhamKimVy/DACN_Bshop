@extends('admin_layout')
@section('admin_content')

<h3><img src="{{asset('public/backend/images/logo_xoanen.png')}}"  alt="" style="width:180px">Chào mừng đến với trang quản lý B-Shop</h3>

@endsection