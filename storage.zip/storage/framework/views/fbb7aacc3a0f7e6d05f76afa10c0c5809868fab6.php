<?php $__env->startSection('admin_content'); ?>
<div class="panel-heading">
    Chi tiết đơn hàng
</div>
<br>
<div class="table-agile-info">
    <div class="panel panel-default">
      <div class="panel-heading">
        Thông tin khách hàng
      </div>
      <div class="row w3-res-tb">
      <div class="table-responsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th>Tên người đặt</th> 
              <th>Địa chỉ Email</th>
              <th>SĐT</th>
              <th>Địa chỉ nhận hàng</th>
       
              <th style="width:30px;"></th>
            </tr>
          </thead>
          <tbody>  
                <tr>
                    <td><?php echo e($orderId->customer_name); ?></td>
                    <td><?php echo e($orderId->customer_email); ?></td>
                    <td><?php echo e($orderId->customer_phone); ?></td>
                    <td><?php echo e($orderId->order_address); ?></td>
              
                </tr>     
          </tbody>
        </table>
      </div>
      <br>
      <br>
    </div>
  </div>
</div>
<br>

<div class="table-agile-info">
    <div class="panel panel-default">
      <div class="panel-heading">
        Danh sách sản phẩm
      </div>
      <div class="row w3-res-tb">
      <div class="table-responsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              
              <th>Sản phẩm</th>
              <th>Giá</th>
              <th>Số lượng</th>
              <th>Tổng tiền</th>
              <th style="width:30px;"></th>
            </tr>
          </thead>
          <tbody> 

          <?php $__currentLoopData = $orderId_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderId_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a><?php echo e($orderId_details->book_name); ?></a></td>
                    <td><?php echo e(number_format($orderId_details->book_price, 0, ',','.')); ?> VND</td>
                    <td><?php echo e($orderId_details->book_sales_quantity); ?></td>
                    <td><?php echo e(number_format($orderId_details->book_price*$orderId_details->book_sales_quantity, 0, ',','.')); ?> VND</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          
        </table>
        
      </div>
      <td style="font-size:20px">Tổng hóa đơn:</td>
			<td style="font-size: 20px;padding:3px"> <?php echo e($orderId_details->order_total); ?></td>
      <br>
      <br>
     				
    </div>
   	
  </div>
  <button style="background-color:green" class="btn btn-secondary" > <a style="color:#fff"  href="<?php echo e(URL::to('/manage-order')); ?>">Quay lại</i></a></button>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/admin/view_order.blade.php ENDPATH**/ ?>