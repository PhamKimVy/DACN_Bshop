
    

<?php $__env->startSection('content'); ?>

	<!--//////////////////////////////////////////////////-->
	<!--///////////////////Product Page///////////////////-->
	<!--//////////////////////////////////////////////////-->
	<div id="page-content" class="single-page">
		<div class="container">
		

			<div class="row">
				<nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
				<ol class="breadcrumb" style="height:55px;text-align: center;vertical-align: middle;">
					<li class="breadcrumb-item" style="padding-top:18px;padding-left:10px"><a style="font-size:25px" href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
					<?php $__currentLoopData = $book_show; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<li class="breadcrumb-item " aria-current="page" style="padding-top:18px"><a href="<?php echo e(URL::to('/danh-muc-san-pham/'.$book_value->category_id)); ?>"><?php echo e($book_value->category_name); ?></a></li>
					<li class="breadcrumb-item " aria-current="page" style="padding-top:18px"><a href="<?php echo e(URL::to('/nha-xuat-ban/'.$book_value->publisher_id)); ?>"><?php echo e($book_value->publisher_name); ?></a></li>
					<li class="breadcrumb-item active" aria-current="page" style="padding-top:18px"><a href=""><?php echo e($book_value->book_name); ?></a></li>
				</ol>
				</nav>
			
			</div>
<!-- thông báo nếu số lượng khách hàng chọn vượt quá tồn kho -->
			<?php 
             $message= Session::get('message');
		
             if($message){//nếu tồn tại message thì in thông báo ra
     
               ?><div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong style=" font-size: 20px"><?php echo e($message); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div><?php
               
             }
			?>
			<div class="row">

				<div id="main-content" class="col-md-12">
					<div class="product" style="padding:110px;padding-top:10px;padding-bottom:30px; display: flex; flex-wrap: wrap; align-items: center;flex-direction: row;">
						<div class="col-md-6">
							<div class="image" style="">
								<img src="<?php echo e(asset('public/uploads/book/'.$book_value->book_image)); ?>" style="width:500px;height:600px" />
								
							</div>
						</div>
						<div class="col-md-6" style="padding:50px">
							<div class="caption">
								<div class="name" style="font-size:19px; padding:5px"><h5 style="font-size:32px"><?php echo e($book_value->book_name); ?></h5></div>
								<div class="info">
									<ul>
										<li style="font-size:19px; padding:5px">Tác giả: <?php echo $book_value->book_author; ?> </li>
										<li style="font-size:19px; padding:5px">Nhà xuất bản: <a href="<?php echo e(URL::to('/nha-xuat-ban/'.$book_value->publisher_id)); ?>"><?php echo e($book_value->publisher_name); ?></a> <h3></li>
									</ul>
								</div>
							
								<form name="form3" method="POST" action="<?php echo e(URL::to('/save-cart')); ?>">
									<?php echo e(csrf_field()); ?>

									<div style="font-size:19px; padding:5px" class="price">Giá: <?php echo e(number_format($book_value->book_price).' '.'VND'); ?><span></span></div>
									<label style="font-size:19px; padding:5px">Số lượng:<input style="width:50px;float: right; margin-top: -5px;" min="1" type="number" class="cart_book_qty_<?php echo e($book_value->book_id); ?>"name ="qty" value="1" ></label> 
										
									</label> 
								
									<div style="font-size:19px; padding:5px">
									<?php 
										$message = Session::get('message');
									
										if($message){//nếu tồn tại message thì in thông báo ra
										echo'<span style="color:red">Vui lòng chọn số lượng phù hợp </span>';
										
										Session::put('message',null);//Cho thông báo chỉ hiện 1 lần
										}
									?><br>
									Số lượng sách còn lại: <span style="color:red"><?php echo e($book_value->book_inventory); ?></span>  </div>
									<input type="hidden" name ="bookid_hidden" value="<?php echo e($book_value->book_id); ?>">

							
								</div>
							
								
										<input type="hidden" value="<?php echo e($book_value->book_inventory); ?>" name="inventory" >
									<?php if($book_value->book_inventory==0){
									?>
									<button type="submit" class="btn btn-1 add-to-cart" style="font-size:15px;background-color:#DF7857" data-id="<?php echo e($book_value->book_id); ?>"  name="">Hết hàng !!!</button>
								
									<?php 
								}else{
									?>
									<button type="submit" class="btn btn-1 add-to-cart" style="font-size:15px;background-color:#DF7857" data-id="<?php echo e($book_value->book_id); ?>"  name="add-to-cart">Thêm giỏ hàng</button>
								<?php } ?>
								</form>
								</div>
							</div>
						</div>
						<div class="clear"></div>
					</div>	
					<div class="product-desc">
						<ul class="nav nav-tabs">
							<li class=""  ><b><a href="#description" style="color:black; font-size: 25px" >Thông tin sách</a></b></li>
						</ul>
						<div class="tab-content">
					
						<p style="vertical-align: middle;"> <?php echo $book_value->book_desc; ?></p>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</div>
					</div>
						<div class="clear"></div>
					</div>
				</div>
			
			</div>
		</div>
	</div>	


	
 <div class="row" style="margin-left: 40px">
		<div class="col-lg-12">
			<div class="heading"><h2>SÁCH LIÊN QUAN</h2></div>
				<div class="products">
					<?php $__currentLoopData = $sachlienquan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12" >
				
						<div class="image"><a href="<?php echo e(URL::to('/chi-tiet-sach/'.$book->book_id)); ?>"><img src="<?php echo e(URL::to('public/uploads/book/'.$book->book_image)); ?>" style="width:300px;height:300px"/></a></div>
						<div class="caption" >
							<div class="name" ><h3><a href="<?php echo e(URL::to('/chi-tiet-sach/'.$book->book_id)); ?>"><?php echo e($book->book_name); ?></a></h3></div>
							<div class="price"><?php echo e(number_format($book->book_price).' '.'VND'); ?></div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
				</div>
					
			</div>
			<?php echo e($sachlienquan->links('pagination::bootstrap-4')); ?>

		</div>
		
		
		</div>
	

<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/pages/book/show_book.blade.php ENDPATH**/ ?>