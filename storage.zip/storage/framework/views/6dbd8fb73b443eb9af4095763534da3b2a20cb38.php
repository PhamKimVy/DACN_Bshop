

    <?php $__env->startSection('content'); ?>
	<!--//////////////////////////////////////////////////-->
	<!--///////////////////contact Page//////////////////-->
	<!--//////////////////////////////////////////////////-->
	<div class="container" style="border-width: 10px;border-style: double; padding: 45px;width: 80%; ">
    <h4 style="float: right;padding-right: 5px;">	BỘ GIÁO DỤC VÀ ĐÀO TẠO</h4>
        <h4>NGÂN HÀNG NHÀ NƯỚC VIỆT NAM</h4>
        
        <center>
            <h4 style="margin:35px">TRƯỜNG ĐẠI HỌC NGÂN HÀNG TP.HCM</h4>
            <img src="<?php echo e(asset('public/frontend/img/logohub.png')); ?>" alt="logo">
            <h5>ĐỒ ÁN CHUYÊN NGÀNH <br> HỆ THỐNG THÔNG TIN KINH DOANH VÀ CHUYỂN ĐỔI SỐ</h5>
            <h2 style="margin:35px">Đề tài: XÂY DỰNG WEBSITE BÁN SÁCH B-SHOP</h2>
            

        </center>
        <div style="height: 300px; font-size: 25px; margin-left:35%;margin-top: 80px; height: 500px">
            <b style="color:black"><p>Sinh viên thực hiện: Phạm Kim Vy <p> <br>
              <p>Mã số sinh viên: 030236200224 </p>  <br>
              <p>  Lớp: DH36CDS02 </p>  <br>
              <p> Giảng viên hướng dẫn: ThS. Nguyễn Phương Nam	</p> </b>
        </div>
            <center><i><h6> TP. HCM, tháng 04 năm 2023</h6></i></center>
   
    </div>


    
  
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/pages/contact.blade.php ENDPATH**/ ?>