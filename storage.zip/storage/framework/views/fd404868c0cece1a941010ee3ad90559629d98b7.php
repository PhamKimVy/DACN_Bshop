
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
     Liệt kê danh mục
    </div>
    
    <div class="table-responsive">
    <?php
                      $message = Session::get('message');
                      if($message){//nếu tồn tại message thì in thông báo ra
                        echo'<span style="color:red">'. $message.'</span>';
                        Session::put('message',null);//Cho thông báo chỉ hiện 1 lần
                      }
                      
                    ?>
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
          
            <th>Tên danh mục</th>
            <th>Mô tả</th>
            <th>Trạng thái</th>
          
            <th style="width:30px;"></th>
          </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $all_category_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
             <td><?php echo e($cate_pro->category_name); ?></td>
            <td><?php echo $cate_pro->category_desc; ?></td>
        
            <td><span class="text-ellipsis">
              <?php 
                if($cate_pro->category_status==0){
              ?>
              <!-- đang up: thì nếu bấm vào sẽ down => active -->
                <a href="<?php echo e(URL::to('/active-category-product/'.$cate_pro->category_id)); ?>"><span class= "fa-thumb-styling fa fa-thumbs-down" style="font-size: 28px; color:red;"></span></a>;
              <?php
               } else{
                 ?>
                 
              <!-- đang down: thì nếu bấm vào sẽ down => unactive -->
                 <a href="<?php echo e(URL::to('/unactive-category-product/'.$cate_pro->category_id)); ?>"><span class= "fa-thumb-styling fa fa-thumbs-up" style="font-size: 28px; color:green;"></span></a>;
                 <?php }
                 ?>
            </span></td>
      
            <td>
              <a href="<?php echo e(URL::to('/edit-category-product/'.$cate_pro->category_id)); ?>" class="active" ui-toggle-class="">
                <i class="fa-styling fa fa-pencil-square-o text-active" style="font-size: 25px"></i>
               </a>
               <a onclick="return confirm('Bạn có chắc muốn xóa?')" href="<?php echo e(URL::to('/delete-category-product/'.$cate_pro->category_id)); ?>" class="active" ui-toggle-class="">
                <i class="fa-styling fa fa-times text-danger text" style="font-size: 25px;">

                </i>
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
   
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/admin/all_category_product.blade.php ENDPATH**/ ?>