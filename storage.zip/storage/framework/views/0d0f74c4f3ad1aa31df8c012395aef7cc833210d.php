
<!DOCTYPE html>
<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">

    <title>Dolphin Book</title>
    <link href="<?php echo e(asset('public/frontend/css/form.css')); ?>" rel="stylesheet" type="text/css" media="all" />

<style>
@import  url('https://fonts.googleapis.com/css?family=Montserrat:400,800');

.has-error{
			color: red;
		}
	
</style>
</head>
<body>

<div class="main-w3layouts wrapper">
    <div class="container" id="container">
        <div class="form-container sign-up-container">
        
        <form name="form2" id="ff2" method="post" action="#" role="form" class="needs-validation" novalidate>
                    <div class="mb-3">
                <h2>TẠO TÀI KHOẢN</h2>
                <div class="form-group">
                        <input type="text"  class="text" placeholder="Họ Tên" name="name" value="" required/>
                        <div class="invalid-feedback">Vui lòng nhập họ tên</div>
                       <div class="has-error">
                        <span> <?php echo(isset($err['name']))?$err['name']:'' ?></span>
                        </div>
                    </div>
                  
                    
                    
                    <div class="form-group">
                        <input class="text email" type="email" placeholder="Email" name="email" value="" required/>
                        <div class="invalid-feedback">Vui lòng nhập email</div>
                        <!-- kiểm tra trùng mail -->
                        <div class="has-error">
                        <span> <?php echo(isset($err['trungmail']))?$err['trungmail']:'' ?></span>
                        </div>
                       
                    </div>
               
                    
                    <div class="form-group">
                  
                      

                        <!-- <div class="input-group mb-3" style=""> -->
                    
                            <input class="text" type="text" placeholder="Số điện thoại" name="phone"  value=""required/>
                      
                            <!-- <input type="text" class="form-control"name="phone" placeholder="Số điện thoại" style="placeholder-color:rgb(73, 1, 35); float:  ;right: px; bottom:5px; width:100px "> -->
                            <!-- <div class="invalid-feedback">Số điện thoại không được bỏ trống</div> -->
                        <!-- </div> -->
                        <div class="invalid-feedback">Vui lòng nhập số điện thoại</div>

                        <div class="has-error">
                            <span> <?php echo(isset($err['phone']))?$err['phone']:'' ?></span>
                        </div>

                    </div>
                    <!-- <label for="basic-url">Your vanity URL</label> -->

                    
                  
                    
                    <div class="form-group">
                        <input class="text" type="password" placeholder="Mật khẩu" name="password"  value=""required/>
                        <div class="invalid-feedback">Vui lòng nhập mật khẩu</div>
                        <div class="has-error">
                        <span> <?php echo(isset($err['mk']))?$err['mk']:'' ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="text w3lpass"  type="password" placeholder="Mật khẩu nhập lại" name="repass" value="" required/>
                        <div class="invalid-feedback">Vui lòng nhập lại mật khẩu</div>
                        <!-- kiểm tra mật khẩu nhập lại có giống mật khẩu vauwf nhập không -->
                        <div class="has-error">
                        <span> <?php echo(isset($err['repass']))?$err['repass']:'' ?></span>
                        </div>
                    
                    </div>
                </div>
					<button type="submit" name="dangky" >Đăng ký</button>
				</form>
        </div>
        <div class="form-container sign-in-container">
            
            <form name="form2" id="ff2" method="post" action="#" role="form" class="needs-validation" novalidate>
                    <h2>ĐĂNG NHẬP</h2>	
						
                    <div class="mb-3">
                    
							<input class="text" type="email"  placeholder="Email" name="email" value="<?php if(isset($_COOKIE['user'])) echo $_COOKIE['user']; ?>" required/>
							<div  class="invalid-feedback">Vui lòng nhập email</div>
						
							<input class="text" type="password"  placeholder="Mật khẩu" name="password"  value="<?php if(isset($_COOKIE['pass'])) echo $_COOKIE['pass']; ?>"required/>
							<div class="invalid-feedback">Vui lòng nhập mật khẩu</div>
							
						
				
                        <div class="wthree-text">
						<label class="anim">
							<input type="checkbox" class="checkbox" value=""<?php if(isset($_COOKIE['user'])) echo "checked"; ?> >
							<span>Lưu mật khẩu</span>
						</label>
					    </div>
					</div>
					<button type="submit" name="dangnhap" >Đăng nhập</button>
				</form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <!-- <h1>Chào mừng bạn đến với Dolphin Book! <br></h1> -->
                    <div class="bubbles">
                        <h1>DOLPHIN Book</h1>
                    </div>
                    <img src="logo2.png" alt="">
                    <p>Bạn đã có tài khoản?</p>
                    <button class="ghost" id="signIn">đăng nhập</button><br>
                    <button class="ghost" id="home" ><a href="<?php echo e(URL::to('/trang-chu')); ?>">Home</a></button>
                </div>
                <div class="overlay-panel overlay-right">
                    <!-- <h1>Chào mừng quay trở lại với Dolphin Book!</h1> -->
                    <div class="bubbles">
                        <h1>DOLPHIN Book</h1>
                    </div>
                    <img src="logo2.png" alt="">
                    <p>Bạn chưa có tài khoản?</p>
                    <button class="ghost" id="signUp" href="formdk.php">Đăng ký</button><br>
                    <button class="ghost" id="home" ><a href="<?php echo e(URL::to('/trang-chu')); ?>">Home</a></button>
                </div>
            </div>
        </div>
    </div>
    <ul class="colorlib-bubbles">
			
      <li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li><center><img src="logo2.png" alt=""></center></li>
			<li></li>
      <li>

      </li>
      <li></li> 
      <img src="" alt="">
    
		</ul>
</div>
    <script>
        const signUpButton = document.getElementById('signUp');
        const signInButton = document.getElementById('signIn');
        const container = document.getElementById('container');

        signUpButton.addEventListener('click', () => {
            container.classList.add('right-panel-active');
            // header(location: 'formdk');
        });

        signInButton.addEventListener('click', () => {
            container.classList.remove('right-panel-active');
        });
    </script>
<script>(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()
    </script>
    
</body>
</html>
<?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/pages/form.blade.php ENDPATH**/ ?>