
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
     LIỆT KÊ KHÁCH HÀNG
    </div>
    
    <div class="table-responsive">
    <?php
                      $message = Session::get('message');
                      if($message){//nếu tồn tại message thì in thông báo ra
                        echo'<span style="color:red">'. $message.'</span>';
                        Session::put('message',null);//Cho thông báo chỉ hiện 1 lần
                      }
                      
                    ?>
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
          
            <th>Họ và tên</th>
            <th>Email</th>
            <th>Số điện thoại</th>
            <th>Đơn hàng</th>
            <th style="width:30px;"></th>
          </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $all_customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
             <td><?php echo e($cus->customer_name); ?></td>
             <td><?php echo e($cus->customer_email); ?></td>
             <td><?php echo e($cus->customer_phone); ?></td>
             <td style="text-align: center">
                <a href="<?php echo e(URL::to('/customer-order/'.$cus->customer_id)); ?>" class="active" style="font-size: 1.3rem" ui-toggle-class="">
                    <i class="fa fa-eye text-success text-active" style="color: blue"></i></a>
              </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
   
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/admin/all_customer.blade.php ENDPATH**/ ?>