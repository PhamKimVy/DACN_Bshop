
<?php $__env->startSection('admin_content'); ?>

<h3><img src="<?php echo e(asset('public/backend/images/logo_xoanen.png')); ?>"  alt="" style="width:180px">Chào mừng đến với trang quản lý B-Shop</h3>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>