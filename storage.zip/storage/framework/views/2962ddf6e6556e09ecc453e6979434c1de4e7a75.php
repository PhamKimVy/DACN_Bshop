

<div class="widget wid-product">
			<div class="heading"><h4>Sách mới nhất</h4></div>
			<div class="content">
				<?php $__currentLoopData = $new_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="product">
					<a href=""><img src="<?php echo e(URL::to('public/uploads/book/'.$book->book_image)); ?>" style="width:80px;height:100px"/></a>
					<div class="wrapper">
						<h5><a href="<?php echo e(URL::to('/chi-tiet-sach/'.$book->book_id)); ?>"><?php echo e($book->book_name); ?></a></h5>
						<div class="price"><?php echo e(number_format($book->book_price).' '.'VND'); ?></div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
<?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/spmoinhat.blade.php ENDPATH**/ ?>