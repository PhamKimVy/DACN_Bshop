<?php $__env->startSection('content'); ?>
<section id="cart_items">
    <div class="container-fluid">
        <h2 class="title text-center" style="padding-top:10px ">Danh sách sản phẩm đã mua</h2>

        <div class="table-responsive cart_info">
            <?php 
            $content = Cart::content();
            
            ?>
            <table class="table table-condensed">
                <thead>
                    <tr class="cart_menu">
                        <td></td>
                        <td class="image">Sản phẩm</td>
                        <td class="description">Giá</td>
                        <td class="price">Số lượng</td>
                        <td class="price">Tổng tiền</td>
                    </tr>
                </thead>
                <tbody>
                     <?php $__currentLoopData = $view_history_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a ><img src="<?php echo e(URL::to('public/uploads/book/'.$pro->book_image)); ?>" height="100px" width="100px"></a></td>
                        <td><a ><?php echo e($pro->book_name); ?></a></td>
                        
                        <td><?php echo e('$'.number_format($pro->book_price, 2, '.',',')); ?></td>
                        <td><?php echo e($pro->book_sales_quantity); ?></td>
                        <td><?php echo e('$'.number_format($pro->book_price*$pro->book_sales_quantity, 2, '.',',')); ?></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php 
									$customer_id = Session::get('customer_id');
                  $customer_name = Session::get('customer_name');
                  
									if($customer_id!=NULL){
								?>
							<button type="" name="" class="btn btn-outline-primary" ><a href="<?php echo e(URL::to('/show-history/'.$customer_id)); ?>" style="color:black">Trở lại</a></button>
                            
									<?php } ?>
        </div>
    </div>
</section> <!--/#cart_items-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/pages/checkout/view_history_order.blade.php ENDPATH**/ ?>