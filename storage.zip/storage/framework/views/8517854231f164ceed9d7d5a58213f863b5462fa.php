         

<?php $__env->startSection('content'); ?>

	<!--//////////////////////////////////////////////////-->
	<!--///////////////////Cart Page//////////////////////-->
	<!--//////////////////////////////////////////////////-->
	<div id="page-content" class="single-page">
		<div class="container">
			<div class="row">
				<nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
				<ol class="breadcrumb" style="height:55px;text-align: center;vertical-align: middle;">
					<li class="breadcrumb-item" style="padding-top:18px;padding-left:10px"><a style="font-size:25px" href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
					
					<li class="breadcrumb-item active" aria-current="page" style="padding-top:18px"><a href="">Đặt hàng thành công</a></li>
				</ol>
				</nav>
			
			</div>
            <div >
            <p style="color:red; font-size:28px">
					Cảm ơn bạn đã đặt hàng. Chúng tôi sẽ liên hệ với bạn trong thời gian sớm nhất!!
				</p>
				<button  class="btn btn-outline-primary" href="<?php echo e(URL::to('/trang-chu')); ?>">	<a class="home" href="<?php echo e(URL::to('/trang-chu')); ?>">Quay lại trang chủ</a>	</button>
		
            </div>

		</div>

					


<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/pages/checkout/order_success.blade.php ENDPATH**/ ?>