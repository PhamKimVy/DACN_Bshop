

    <?php $__env->startSection('content'); ?>
	
	<!--//////////////////////////////////////////////////-->
	<!--///////////////////Category Page//////////////////-->
	<!--//////////////////////////////////////////////////-->
	<div id="page-content" class="single-page">
		<div class="container">
			<div class="row">
				<nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
				<ol class="breadcrumb" style="height:55px;text-align: center;vertical-align: middle;">
					<li class="breadcrumb-item" style="padding-top:18px;padding-left:10px"><a style="font-size:25px" href="<?php echo e(URL::to('/trang-chu')); ?>">Trang chủ</a></li>
					<?php $__currentLoopData = $category_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="breadcrumb-item active" aria-current="page" style="padding-top:18px"><a href=""><?php echo e($name->category_name); ?></a></li>
           			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ol>
				</nav>
			
			</div>

			<div class="row">
				<div id="main-content" class="col-md-8">
					<div class="row">
						<div class="col-md-12">
							<div class="products">
							<?php $__currentLoopData = $category_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-lg-4 col-md-4 col-xs-12" style="min-height:500px">
								<div class="product" style="width:230px; margin:10px">
										<div class="image">
											<a href="<?php echo e(URL::to('/chi-tiet-sach/'.$book->book_id)); ?>">
												<img src="<?php echo e(URL::to('public/uploads/book/'.$book->book_image)); ?>" style="width:300px;height:300px"/>
											</a>
										</div>
										<div class="caption">
											<div class="name" style="height:50px"><h3><a href="<?php echo e(URL::to('/chi-tiet-sach/'.$book->book_id)); ?>"><?php echo e($book->book_name); ?></a></h3></div>
											<div class="price"><?php echo e(number_format($book->book_price).' '.'VND'); ?></div>
										</div>
										<form method="POST" action="<?php echo e(URL::to('/save-cart')); ?>">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" name ="bookid_hidden" value="<?php echo e($book->book_id); ?>">
										<input type="hidden" value="<?php echo e($book->book_inventory); ?>" name="inventory" >
										<input type="hidden" name="qty" value="1" />
										
											
										<button type="submit" class="btn btn-1 add-to-cart" style="font-size:15px;background-color:#DF7857" data-id="<?php echo e($book->book_id); ?>"  name="add-to-cart">Thêm giỏ hàng</button>
									
										</form>
									</div>
								</div>
								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<?php echo e($category_book->links('pagination::bootstrap-4')); ?>

						</div>
	
					</div>
		
				</div>
		

				<!-- start -->
				<div id="sidebar" class="col-3" style=" margin-left:45px">
					<div class="widget wid-categories">
						<div class="heading"><h4>Danh mục sản phẩm</h4></div>
						<div class="content">
							<ul>
								<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e(URL::to('/danh-muc-san-pham/'.$cate->category_id)); ?>"><?php echo e($cate->category_name); ?></a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
					<div class="widget wid-categories">
						<div class="heading"><h4>Nhà xuất bản</h4></div>
						<div class="content">
							<?php $__currentLoopData = $publisher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li><a href="<?php echo e(URL::to('/nha-xuat-ban/'.$pub->publisher_id)); ?>"><?php echo e($pub->publisher_name); ?></a></li>
							</ul>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>    
				
					</div>
				</div>
			</div>	 
		</div>	 
	</div>
    <?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/pages/category/show_category.blade.php ENDPATH**/ ?>