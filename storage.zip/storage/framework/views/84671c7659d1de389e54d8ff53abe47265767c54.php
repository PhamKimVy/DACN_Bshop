
<?php $__env->startSection('admin_content'); ?>
<div class="row">
            <div class="col-lg-12">
                    <section class="panel">
                        <header class="panel-heading">
                            SỬA Sách 
                        </header>
                        <div class="panel-body">
                            <?php $__currentLoopData = $edit_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="position-center">
                            <?php
                                $message = Session::get('message');
                                if($message){//nếu tồn tại message thì in thông báo ra
                                    echo'<span style="color:red">'. $message.'</span>';
                                    Session::put('message',null);//Cho thông báo chỉ hiện 1 lần
                                }
                                
                            ?>
                                <!-- <form role="form" action="" method="post"> -->
                                <form role="form" action="<?php echo e(URL::to('/update-book/'.$edit_value->book_id)); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                

                                <!--  code cop từ add-->
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Tên Sách</label>
                                    <input type="text" class="form-control" name="book_name" id="exampleInputEmail1" value="<?php echo e($edit_value->book_name); ?>">
                                    
                                </div>
                                
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Hình ảnh Sách</label>
                                    <input type="file" class="form-control" name="book_image" id="exampleInputEmail1" >
                                    <img scr="<?php echo e(URL::to('public/uploads/book/'.$edit_value->book_image)); ?>" height="100" width="100">    
                         
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Số lượng tồn kho</label>
                                    <input type="text" class="form-control" name="book_inventory" id="exampleInputEmail1" value="<?php echo e($edit_value->book_inventory); ?>">
                                    
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Giá Sách</label>
                                    <input type="text" class="form-control" name="book_price" id="exampleInputEmail1" value="<?php echo e($edit_value->book_price); ?>">
                                    
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Mô tả Sách</label>
                                    <textarea style="resize: none" rows="8" class="form-control" id="ckeditora2" name="book_desc" ><?php echo e($edit_value->book_desc); ?></textarea>
                                    <!-- <div class="invalid-feedback">Vui lòng nhập mô t Sách</div></div> -->
                                </div>
                                <div class="form-group">
                                   
                                    <label for="exampleInputEmail1">Tác giả</label>
                                    <input type="text" class="form-control" name="book_author" id="exampleInputEmail1" placeholder="Tác giả" value="<?php echo e($edit_value->book_author); ?>">
                                    
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Danh mục sản phẩm</label>
                                    <select  name="book_cate" class="form-control input-lg m-bot15">
                                        <?php $__currentLoopData = $cate_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($cate->category_id==$edit_value->category_id): ?>
                                        <option selected value= "<?php echo e($cate->category_id); ?>"><?php echo e($cate->category_name); ?></option>
                                        <?php else: ?>
                                        <option value= "<?php echo e($cate->category_id); ?>"><?php echo e($cate->category_name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                    </select>
                                   
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Nhà xuẩt bản</label>
                                  
                                    <select  name="publisher_id" class="form-control input-lg m-bot15">
                                        <?php $__currentLoopData = $pub_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pub_book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($pub_book->publisher_id==$edit_value->publisher_id): ?>
                                        <option selected value= "<?php echo e($pub_book->publisher_id); ?>"><?php echo e($pub_book->publisher_name); ?></option>
                                       <?php else: ?>
                                        <option value= "<?php echo e($pub_book->publisher_id); ?>"><?php echo e($pub_book->publisher_name); ?></option>
                                       <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Hiển thị</label>
                                    <select  name="book_status" class="form-control input-lg m-bot15">
                                        <option value=0>Ẩn</option>
                                        <option value=1>Hiện</option>
                                    </select>

                                </div>
                                <button type="submit" name="update_book"  class="btn btn-info">Cập nhật Sách</button>
                                <button style="background-color:green" class="btn btn-secondary" > <a style="color:#fff"  href="<?php echo e(URL::to('/all-book')); ?>">Quay lại</a></button>
						    
                            </form>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </section>

            </div>
            
        </div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XAMPP\xampp\htdocs\B_shop\resources\views/admin/edit_book.blade.php ENDPATH**/ ?>